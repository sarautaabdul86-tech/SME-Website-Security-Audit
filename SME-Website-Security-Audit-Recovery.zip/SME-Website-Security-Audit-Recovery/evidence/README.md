Save sanitized screenshots and evidence from authorized lab tests here. Do not include credentials or private client data.
