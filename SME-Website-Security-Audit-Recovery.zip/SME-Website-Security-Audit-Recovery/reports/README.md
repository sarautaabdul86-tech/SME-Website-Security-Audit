Generated JSON audit reports are saved here. Review them for sensitive information before sharing or committing.
